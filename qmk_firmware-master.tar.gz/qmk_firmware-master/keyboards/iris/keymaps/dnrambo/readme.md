# Colemak layout for Iris rev2.1 with Mac and Windows layers and a Gaming Layer.
# Symbol layer is based on my Planck layout, so it provides numbers, symbols, and volume controls.
# Two Navigation layers, for Mac and Windows Colemak layers respectively.