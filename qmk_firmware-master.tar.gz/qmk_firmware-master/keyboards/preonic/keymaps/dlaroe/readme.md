# Dale's Preonic layout 

Really just my Planck layout for the Preonic.

The hardware number row is mostly to avoid context switching delay inherent in receiving auditory input while trying to type. Frankly I like my Planck Game layer more than I like using the number row.

I cut most of the plate vertical supports on the left side to use the Rev. 1 Preonic PCB's alternate switch placement to allow the use of 1.25 mods.
