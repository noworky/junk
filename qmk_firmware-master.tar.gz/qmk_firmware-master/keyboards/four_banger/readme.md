Four Banger
===

A 2x2 macro pad sold by 1up Keyboards - designed by Bishop Keyboards

Keyboard Maintainer: QMK Community  
Hardware Supported: Four Banger Keyboard PCB  
Hardware Availability: [1up Keyboards](https://1upkeyboards.com/)

Make example for this keyboard (after setting up your build environment):

    make four_banger:default

See [build environment setup](https://docs.qmk.fm/build_environment_setup.html) then the [make instructions](https://docs.qmk.fm/make_instructions.html) for more information.