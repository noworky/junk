# The default keymap for LFK78
