![Daisy Layout Image](https://imgur.com/9mSF0yf)

# Default Daisy Layout

This is the default layout as offered by KPRepublic's TMK firmware for the Daisy with a few minor tweaks for usability made by me.
