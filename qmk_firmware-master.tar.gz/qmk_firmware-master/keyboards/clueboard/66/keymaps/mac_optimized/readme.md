![Clueboard Layout Image](http://i.imgur.com/7oZCsHF.png)

# Default Clueboard Layout for Mac

This is the default Clueboard layout with Alt and GUI switched to match Mac
conventions.
