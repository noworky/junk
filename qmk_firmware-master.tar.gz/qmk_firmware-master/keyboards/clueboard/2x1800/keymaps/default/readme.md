# The default keymap for 2x1800
