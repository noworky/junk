# Mike's Rethought Planck

- Music/Audio
- Dynamic Macros
- Media Keys
- Works with iPhone Camera Adapter

## Layers

Qwerty for letters and mods.

Numsym for all numbers and symbols used in typing. Follows a similar approach to
planck but puts both on the same layer eschewing the F-keys.  

Fkeys layer is for the seldom used stuff like F-keys and some additional features
such as dynamic macros, media keys, and a sleep shortcut for OS X.

Adjust layer is mainly for keyboard configuration stuff.

## Dynamic Macros

Hold TAB key, then press ";" to record macro 1 and "'" to record macro 2.

When you are done recording, press TAB again.

For playback of macros, TAB+"," plays macro 1 and TAB+","plays macro 2.
