# rai-suta's Planck Layout

This keymap assumes that the keyboard is recognized as JIS keyboard from the OS.
