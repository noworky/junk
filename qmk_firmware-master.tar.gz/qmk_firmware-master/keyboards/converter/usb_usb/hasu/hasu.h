#ifndef HASU_H
#define HASU_H

#include QMK_KEYBOARD_H

#endif
