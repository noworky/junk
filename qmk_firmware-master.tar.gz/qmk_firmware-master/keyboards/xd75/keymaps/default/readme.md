# The default keymap for xd75
