# RGB on the TADA68
This board has unused pins, which means that you can add some nice RGB leds, although they have no use at this momen because not a single transparent case has been made yet. Here's where you have to solder the wires on the PCB:
![Image of solder points for RGB on the Tada68](http://i.imgur.com/5Xmiz6Q.jpg)