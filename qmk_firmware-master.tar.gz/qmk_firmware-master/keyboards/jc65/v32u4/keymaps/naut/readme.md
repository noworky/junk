Naut's Keymap
=======
 
Layer 1: HHKB Split backspace, 6.25u space, control on caps, Fn on L-Ctl.

Layer 2: F Row on numrow, caps on tab, media shortcuts on arrows

Layer 3: Mac Media buttons on numrow

Layer 4: RGB control

Layer 5: Keyboard off (for mashing purposes and reset)

Keymap Maintainer: [Jason Barnachea](https://github.com/nautxx)

Difference from base layout: HHKBish layout. HHKB Fn layer. Mac media layer. RGB control layer. Button mashing layer.

Intended usage: Daily driver for keyboard peacocking. 
