Default Keymap
=======

Default plain keymap with only a base layer.

Keymap Maintainer: [Jason Barnachea](https://github.com/nautxx)

Difference from base layout: None.

Intended usage: Reference layout.
