# DZ60

![dz60](https://cdn.shopify.com/s/files/1/1473/3902/files/1_6525343b-ee62-47e8-882a-05e316136a3f.jpg?v=1501657073)

A customizable 60% keyboard.

Keyboard Maintainer: QMK Community  
Hardware Supported: DZ60  
Hardware Availability: [kbdfans](https://kbdfans.myshopify.com/collections/pcb/products/dz60-60-pcb?variant=40971616717)

Make example for this keyboard (after setting up your build environment):

    make dz60:default

See [build environment setup](https://docs.qmk.fm/build_environment_setup.html) then the [make instructions](https://docs.qmk.fm/make_instructions.html) for more information.
