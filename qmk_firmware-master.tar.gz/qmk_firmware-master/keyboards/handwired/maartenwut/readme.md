# maartenwut handwired

Custom handwired keyboard for maartenwut.

Keyboard Maintainer: [Maarten Dekekrs](https://github.com/maartenwut)  
Hardware Supported: Custom handwired  
Hardware Availability: 

Make example for this keyboard (after setting up your build environment):

    make handwired/maartenwut:default

See [build environment setup](https://docs.qmk.fm/build_environment_setup.html) then the [make instructions](https://docs.qmk.fm/make_instructions.html) for more information.