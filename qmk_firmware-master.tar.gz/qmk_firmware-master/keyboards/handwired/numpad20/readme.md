# numpad20 handwired

Custom handwired 20 key numpad.

Keyboard Maintainer: [Danny](https://github.com/nooges)  
Hardware Supported: Custom handwired 20 key numpad  
Hardware Availability: 

Make example for this keyboard (after setting up your build environment):

    make handwired/numpad20:default

See [build environment setup](https://docs.qmk.fm/build_environment_setup.html) then the [make instructions](https://docs.qmk.fm/make_instructions.html) for more information.