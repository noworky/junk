# ErgoDox EZ mpiechotka Configuration

Modification of ErgoDox EZ Colemak layout with additional QWERTY/software Colemak layer and change of the special keys.



